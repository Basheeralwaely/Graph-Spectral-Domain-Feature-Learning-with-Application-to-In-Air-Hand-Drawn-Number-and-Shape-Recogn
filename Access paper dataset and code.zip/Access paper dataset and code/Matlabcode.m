% This is the code of the "Graph Spectral Domain Feature Learning with Application to In-Air Hand-Drawn 
% Number and Shape Recognition" paper, all the right are reserve.
% you must cite this paper to use the code 
% Alwaely B, Abhayaratne C. Graph Spectral Domain Feature Learning With Application to in-Air Hand-Drawn Number and Shape Recognition.
% IEEE Access. 2019 Oct 31;7:159661-73.
% " https://ieeexplore.ieee.org/abstract/document/8888161"


% upload the dataset 
% Go to this link to uplaod the dataset   
% https://figshare.shef.ac.uk/articles/In-Air_Hand-Drawn_Number_and_Shape_Dataset/7381472/1

clear,clc, close all
load('label.mat');load('X.mat');load('Y.mat');load('Z.mat')               % Load the labels,x,y,z axes
[len,n]=size(X); 
for k=1:len
    x=X(k,:);
    y=Y(k,:);
    z=Z(k,:);
    e=zeros(n);                                            %% graph formulation
    for i=1:n
        for j=1:i
            dist=sqrt((x(i)-x(j))^2+(y(i)-y(j))^2+(z(i)-z(j))^2);         
            e(i,j)=dist;e(j,i)=dist;
        end
    end     
    % below is the code to compute most of the equations in the paper
            m=max(max(e));e=exp(e/(m/log(m)));              %% compute the adjacency matrix (E.q 2)
            D=sum(e);D=diag(D);                             %% compute the degree matrix (E.q 6)
            L=D-e;                                          %% The combinatorial graph Laplacian matrix (E.q 5)
            L=D^(-1/2)*L*D^(-1/2);                          %% The normalised graph Laplacian matrix (E.q 7)
            [eignvector, ev]=eig(L);                        %% Eigen bases (E.q 8)
            
            % Feature extraction %%
            b(k,:)=eignvector(:,1);                         %% The first eigenvector (E.q 9)
            for ii=1:n
                F1(k,ii)=(ii^2)*b(k,ii);                    %% Compute F1 (E.q 10&11)
            end
                F2(k,1:n)=sqrt(x.^2+y.^2).*b(k,:);          %% Compute F2 (E.q 12)
                F3(k,1:n)=(180/pi)*atan(abs(x./y));         %% Compute F3 (E.q 13)
end

% put all the features and the label in the same matrix to be classified
Features=label;
Features(:,2:n+1)=F1;
Features(:,n+2:(n*2)+1)=F2;
Features(:,(2*n)+2:(3*n)+1)=F3;

% After that, the features can be classified using different machine learning methods.
                