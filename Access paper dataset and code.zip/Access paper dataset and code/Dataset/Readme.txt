%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%      
                    "In-Air Hand-Drawn Number and Shape Dataset"

                    Basheer Alwaely and Charith Abhayaratne

               Department of Electronic and Electrical Engineering
       
                          The University of Sheffield
                        Sheffield, S1 3JD, United Kingdom
           Email: b.alwaely@sheffield.ac.uk, c.abhayaratne@sheffield.ac.uk

                                 26/11/2018

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
This dataset creation has received The University of Sheffield ethics approval 
under application (023005) granted on (19/10/2018).
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

This data set contains in-air hand-written numbers and shapes data used in the paper "Graph Spectral Features for In-Air Hand-Drawn Number and Shape Recognition" submitted to IEEE Trans. Multimedia submitted in November 2018.

This data set contains the following:
-Readme.txt
-Number Folder (With 2 sub folders for Matlab and Excel)
-Shapes Folder (With 2 sub folders for Matlab and Excel)

The data sets include the in-air drawn number and shape hand movement path captured by a Kinect sensor. The number sub dataset includes 500 instances per each number 0 to 9, resulting in a total of 5000 number data instances. Similarly, the shape sub dataset also includes 500 instances per each shape for  10 different arbitrary 2D shapes, resulting in a total of 5000 shape instances. The data set provides X, Y, Z coordinates of the hand movement path data in Matlab (M-file) and Excel formats and their corresponding labels. The dataset provides the raw sampled hand path with original sampling rates and without any normalizing nor smoothing, resulting in various numbers of data points within a given hand path.

Matlab users can use the code below to load and display the samples
load('Data.mat')
figure;k=1;
for i=1:50
    subplot(5,10,k)
    plot3(nonzeros(Data.x(i,:)),nonzeros(Data.y(i,:)),nonzeros(Data.z(i,:)));axis equal 
    k=k+1;
end

For Excel users, there are 3 files showing X,Y,Z cordinates,respectively for a smaple recorded in each row. The corresponding label is available in the same row of the file named "labels" 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

If you use this data set, please cite our previous publication in your paper as follows:

Basheer Alwaely and Charith Abhayaratne,"Graph Spectral domain feature representation for in-air drawn number recognition", EUSIPCO 2017,  pp 370-374, 2017.

@inproceedings{alwaely2017graph,
	title={Graph spectral domain feature representation for in-air drawn number recognition},
	author={Alwaely, Basheer and Abhayaratne, Charith},
	booktitle={Proc. European Signal Processing Conference (EUSIPCO)},
	pages={370--374},
	year={2017},
	organization={}
}


Copyright license: CC-BY-4.0

List of files:
Readme.txt
\Numbers\Excel\label.xlsx   %labels of the number samples 
\Numbers\Excel\X.xlsx  %coordinates of the number samples 
\Numbers\Excel\Y.xlsx  %coordinates of the number samples 
\Numbers\Excel\Z.xlsx  %coordinates of the number samples
\Numbers\Matlab\label.xlsx   %labels of the number samples 
\Numbers\Matlab\X.xlsx  %coordinates of the number samples 
\Numbers\Matlab\Y.xlsx  %coordinates of the number samples 
\Numbers\Matlab\Z.xlsx  %coordinates of the number samples
\Shapes\Excel\label.xlsx   %labels of the shape samples 
\Shapes\Excel\X.xlsx  %coordinates of the shape samples 
\Shapes\Excel\Y.xlsx  %coordinates of the shape samples 
\Shapes\Excel\Z.xlsx  %coordinates of the shape samples
\Shapes\Matlab\label.xlsx   %labels of the shape samples 
\Shapes\Matlab\X.xlsx  %coordinates of the shape samples 
\Shapes\Matlab\Y.xlsx  %coordinates of the shape samples 
\Shapes\Matlab\Z.xlsx  %coordinates of the shape samples







